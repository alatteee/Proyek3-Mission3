<?php

return [
    'failed'   => 'Email atau password salah.',
    'password' => 'Password salah.',
    'throttle' => 'Terlalu banyak percobaan masuk. Coba lagi dalam :seconds detik.',
];
