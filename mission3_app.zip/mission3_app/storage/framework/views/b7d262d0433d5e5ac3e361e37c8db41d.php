<?php if (isset($component)) { $__componentOriginal7651faf8e4a1e278424aad70c82de3ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7651faf8e4a1e278424aad70c82de3ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.layout','data' => ['title' => 'Student Detail']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Student Detail')]); ?>
  <div class="rounded-2xl border border-gray-200 bg-white p-6 shadow-md">
    <div class="mb-6 flex items-center justify-between">
      <h3 class="text-xl font-semibold text-gray-800">
        <?php echo e($student->full_name); ?>

      </h3>
      <div class="flex gap-2">
        <a href="<?php echo e(route('admin.students.edit', $student)); ?>"
           class="rounded-lg border border-gray-300 px-3 py-1.5 text-gray-700 hover:bg-gray-100">Edit</a>
        <a href="<?php echo e(route('admin.students.index')); ?>"
           class="rounded-lg border border-gray-300 px-3 py-1.5 text-gray-700 hover:bg-gray-100">Back</a>
      </div>
    </div>

    <dl class="grid gap-6 sm:grid-cols-2">
      <div>
        <dt class="text-sm text-gray-500">NIM</dt>
        <dd class="mt-1 font-medium text-gray-900"><?php echo e($student->nim); ?></dd>
      </div>
      <div>
        <dt class="text-sm text-gray-500">Entry Year</dt>
        <dd class="mt-1 font-medium text-gray-900"><?php echo e($student->entry_year); ?></dd>
      </div>
      <div>
        <dt class="text-sm text-gray-500">Major</dt>
        <dd class="mt-1 font-medium text-gray-900"><?php echo e($student->major); ?></dd>
      </div>
      <div>
        <dt class="text-sm text-gray-500">Phone</dt>
        <dd class="mt-1 font-medium text-gray-900"><?php echo e($student->phone ?? '—'); ?></dd>
      </div>

      
      <div class="sm:col-span-2 border-t pt-4">
        <dt class="text-sm text-gray-500">User Account</dt>
        <dd class="mt-2 grid gap-2 sm:grid-cols-3">
          <div>
            <div class="text-xs text-gray-500">Username</div>
            <div class="font-medium text-gray-900"><?php echo e($student->user->username ?? '—'); ?></div>
          </div>
          <div>
            <div class="text-xs text-gray-500">Email</div>
            <div class="font-medium text-gray-900"><?php echo e($student->user->email ?? '—'); ?></div>
          </div>
          <div>
            <div class="text-xs text-gray-500">Role</div>
            <div class="font-medium text-gray-900"><?php echo e($student->user->role ?? 'student'); ?></div>
          </div>
        </dd>
      </div>
    </dl>
  </div>

  
  <div class="mt-6 rounded-2xl border border-gray-200 bg-white p-6 shadow-md">
    <div class="mb-4 flex items-center justify-between">
      <h3 class="text-lg font-semibold text-gray-800">
        Enrolled Courses (<?php echo e($courses->total()); ?>)
      </h3>

      
      <form method="POST" action="<?php echo e(route('admin.students.enroll', $student)); ?>" class="flex items-center gap-2">
        <?php echo csrf_field(); ?>
        <select name="course_id"
                class="rounded-lg border-gray-300 text-sm focus:border-blue-600 focus:ring-blue-600">
          <option value="">-- choose course --</option>
          <?php $__currentLoopData = $availableCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>"><?php echo e($c->course_code); ?> — <?php echo e($c->course_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="rounded-lg bg-blue-700 px-3 py-2 text-white text-sm hover:bg-blue-800">
          Enroll
        </button>
      </form>
    </div>

    <?php if($courses->isEmpty()): ?>
      <p class="text-gray-500">Belum ada course yang diambil.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-gray-50 text-gray-600">
            <tr>
              <th class="px-4 py-2 text-left">Code</th>
              <th class="px-4 py-2 text-left">Course</th>
              <th class="px-4 py-2 text-left">Credits</th>
              <th class="px-4 py-2 text-left">Semester</th>
              <th class="px-4 py-2 text-left">Enrolled At</th>
              <th class="px-4 py-2 text-left">Grade</th>
              <th class="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="hover:bg-gray-50">
                <td class="px-4 py-2"><?php echo e($c->course_code); ?></td>
                <td class="px-4 py-2"><?php echo e($c->course_name); ?></td>
                <td class="px-4 py-2"><?php echo e($c->credits); ?> SKS</td>
                <td class="px-4 py-2"><?php echo e($c->semester ?? '—'); ?></td>
                <td class="px-4 py-2">
                  <?php echo e($c->pivot->enroll_date ? \Carbon\Carbon::parse($c->pivot->enroll_date)->format('d M Y') : '—'); ?>

                </td>
                <td class="px-4 py-2">
                  <form method="POST" action="<?php echo e(route('admin.students.grade', [$student, $c])); ?>" class="flex items-center gap-2">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>

                    
                    <input type="number" name="score" min="0" max="100"
                          value="<?php echo e($c->pivot->score); ?>"
                          placeholder="score"
                          class="w-20 rounded border-slate-300 text-sm focus:border-blue-600 focus:ring-blue-600">

                    
                    <select name="letter" class="rounded border-slate-300 text-sm focus:border-blue-600 focus:ring-blue-600">
                      <option value="">auto</option>
                      <?php $__currentLoopData = ['A','AB','B','BC','C','D','E']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $L): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($L); ?>" <?php if($c->pivot->letter === $L): echo 'selected'; endif; ?>><?php echo e($L); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button type="submit" class="rounded bg-blue-700 px-3 py-1.5 text-white text-sm hover:bg-blue-800">
                      Save
                    </button>
                  </form>

                  <?php if(!is_null($c->pivot->grade_point)): ?>
                    <div class="mt-1 text-xs text-slate-500">
                      GPA pt: <?php echo e(number_format($c->pivot->grade_point, 2)); ?>

                    </div>
                  <?php endif; ?>
                </td>
                <td class="px-4 py-2 text-right">
                  <form method="POST" action="<?php echo e(route('admin.students.unenroll', [$student, $c])); ?>"
                        onsubmit="return confirm('Remove this course from student?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="rounded-lg border border-gray-300 px-3 py-1.5 text-gray-700 hover:bg-gray-100">
                      Unenroll
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

      <div class="mt-4">
        <?php echo e($courses->links()); ?>

      </div>
    <?php endif; ?>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7651faf8e4a1e278424aad70c82de3ba)): ?>
<?php $attributes = $__attributesOriginal7651faf8e4a1e278424aad70c82de3ba; ?>
<?php unset($__attributesOriginal7651faf8e4a1e278424aad70c82de3ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7651faf8e4a1e278424aad70c82de3ba)): ?>
<?php $component = $__componentOriginal7651faf8e4a1e278424aad70c82de3ba; ?>
<?php unset($__componentOriginal7651faf8e4a1e278424aad70c82de3ba); ?>
<?php endif; ?>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/admin/students/show.blade.php ENDPATH**/ ?>