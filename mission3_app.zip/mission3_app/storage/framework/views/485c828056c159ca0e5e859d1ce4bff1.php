<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'Dashboard']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'Dashboard']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo e($title); ?> — Admin</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="bg-slate-50 text-slate-800">
  <div class="min-h-screen flex">

    
    <aside class="hidden md:block w-64 shrink-0 bg-white border-r border-slate-200">
      <div class="flex items-center gap-3 px-4 py-4">
        <span class="font-bold text-2xl text-indigo-600">Academia</span>
      </div>
      <?php echo $__env->make('admin.partials.sidebar-inner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
    </aside>

    <main class="flex-1">
      
      <header class="sticky top-0 z-10 bg-white/80 backdrop-blur border-b border-slate-200">
        <div class="h-16 max-w-6xl mx-auto px-4 flex items-center w-full">
          <h1 class="text-lg font-semibold"><?php echo e($title); ?></h1>
          <div class="flex-1"></div>
          <div class="flex items-center gap-4">
            <div class="text-right leading-tight">
              <p class="font-semibold text-slate-900">
                <?php echo e(auth()->user()->full_name ?? auth()->user()->name ?? 'Administrator'); ?>

              </p>
              <p class="text-sm text-slate-500 capitalize"><?php echo e(auth()->user()->role ?? 'admin'); ?></p>
            </div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>
              <button class="rounded-lg bg-red-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-red-500">
                Logout
              </button>
            </form>
          </div>
        </div>
      </header>

      <div class="max-w-6xl mx-auto px-4 py-6">
        <?php echo e($slot); ?>

      </div>
    </main>
  </div>
</body>
</html>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/components/admin/layout.blade.php ENDPATH**/ ?>