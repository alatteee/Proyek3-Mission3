<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'Auth']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'Auth']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo e($title); ?> — Academia</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="min-h-screen antialiased
             bg-gradient-to-br from-sky-50 via-indigo-50 to-blue-100">

  <main class="min-h-screen flex items-center justify-center p-4">
    <section
      class="w-full max-w-4xl grid md:grid-cols-2 rounded-2xl bg-white shadow-2xl ring-1 ring-black/5 overflow-hidden">

      
      <div class="p-8 md:p-10">
        <?php echo e($slot); ?>

      </div>

      
      <div class="relative hidden md:flex items-center justify-center">
        <div class="absolute inset-0 bg-gradient-to-br
                    from-blue-600 via-indigo-500 to-sky-500 opacity-90"></div>
      
        <div class="absolute inset-0 backdrop-blur-[1px]"></div>

        <div class="relative text-white">
          <div class="text-2xl font-bold drop-shadow-sm">Academia</div>
        </div>
      </div>

    </section>
  </main>

</body>
</html>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/components/layouts/auth.blade.php ENDPATH**/ ?>