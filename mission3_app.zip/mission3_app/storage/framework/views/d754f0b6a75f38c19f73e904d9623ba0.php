<?php if (isset($component)) { $__componentOriginale049caea0b4efc5bb49a3781ed38b732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale049caea0b4efc5bb49a3781ed38b732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student.layout','data' => ['title' => 'Browse Courses']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('student.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Browse Courses']); ?>
  <?php if(session('ok')): ?>
    <div class="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-700">
      <?php echo e(session('ok')); ?>

    </div>
  <?php endif; ?>

  <div class="mb-4 flex items-center justify-between">
    <h2 class="text-xl font-semibold text-slate-900">All Courses</h2>
    <form method="get">
      <input name="q" value="<?php echo e($q); ?>" placeholder="Search code/name..."
             class="rounded-xl border border-slate-300 px-3 py-2 text-sm
                    focus:border-emerald-500 focus:ring-emerald-500 focus:outline-none">
    </form>
  </div>

  <div class="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
    <table class="min-w-full text-sm">
      <thead class="bg-slate-50 text-slate-700">
        <tr>
          <th class="px-4 py-3 text-left font-semibold">Code</th>
          <th class="px-4 py-3 text-left font-semibold">Name</th>
          <th class="px-4 py-3 text-left font-semibold">Credits</th>
          <th class="px-4 py-3 text-left font-semibold">Semester</th>
          <th class="px-4 py-3 text-right font-semibold">Action</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-200 text-slate-900">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-mono"><?php echo e($c->course_code); ?></td>
            <td class="px-4 py-3"><?php echo e($c->course_name); ?></td>
            <td class="px-4 py-3"><?php echo e($c->credits); ?> SKS</td>
            <td class="px-4 py-3"><?php echo e($c->semester ?? '—'); ?></td>
            <td class="px-4 py-3">
              <div class="flex justify-end">
                <?php $mine = isset($my) ? $my->get($c->id) : null; ?>

                <?php if(in_array($c->id, $enrolledIds)): ?>
                  <span class="rounded-lg bg-emerald-50 px-3 py-1.5 text-emerald-700">
                    Enrolled<?php echo e($mine && $mine->pivot->letter ? ' ('.$mine->pivot->letter.')' : ''); ?>

                  </span>
                <?php else: ?>
                  <form method="post" action="<?php echo e(route('student.courses.enroll',$c)); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="rounded-lg bg-emerald-600 px-3 py-1.5 text-white hover:bg-emerald-700">
                      Enroll
                    </button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <div class="p-4"><?php echo e($courses->links()); ?></div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale049caea0b4efc5bb49a3781ed38b732)): ?>
<?php $attributes = $__attributesOriginale049caea0b4efc5bb49a3781ed38b732; ?>
<?php unset($__attributesOriginale049caea0b4efc5bb49a3781ed38b732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale049caea0b4efc5bb49a3781ed38b732)): ?>
<?php $component = $__componentOriginale049caea0b4efc5bb49a3781ed38b732; ?>
<?php unset($__componentOriginale049caea0b4efc5bb49a3781ed38b732); ?>
<?php endif; ?>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/student/courses/index.blade.php ENDPATH**/ ?>