<?php if (isset($component)) { $__componentOriginale049caea0b4efc5bb49a3781ed38b732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale049caea0b4efc5bb49a3781ed38b732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student.layout','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('student.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
  <div class="grid gap-6 md:grid-cols-3">
    <div class="rounded-2xl bg-emerald-600 p-5 text-white shadow-sm">
      <div class="text-4xl font-bold leading-none"><?php echo e($totalCourses); ?></div>
      <div class="mt-2 text-sm/5 opacity-90">All Courses</div>
    </div>
    <div class="rounded-2xl bg-emerald-600 p-5 text-white shadow-sm">
      <div class="text-4xl font-bold leading-none"><?php echo e($enrolledCount); ?></div>
      <div class="mt-2 text-sm/5 opacity-90">My Courses</div>
    </div>
    <div class="rounded-2xl bg-emerald-600 p-5 text-white shadow-sm">
      <div class="text-4xl font-bold leading-none"><?php echo e($availableToTake); ?></div>
      <div class="mt-2 text-sm/5 opacity-90">Available</div>
    </div>
  </div>

  <div class="mt-8 grid gap-6 md:grid-cols-2">
    <div class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div class="text-xs font-medium text-slate-500">Welcome</div>
      <div class="mt-1 text-xl font-semibold text-slate-900">
        <?php echo e($student->full_name ?? $user->full_name ?? 'Student'); ?>

      </div>
      <dl class="mt-4 grid gap-y-2 text-sm text-slate-700">
        <div class="flex justify-between"><dt class="text-slate-500">NIM</dt><dd class="font-medium"><?php echo e($student->nim ?? '—'); ?></dd></div>
        <div class="flex justify-between"><dt class="text-slate-500">Major</dt><dd class="font-medium"><?php echo e($student->major ?? '—'); ?></dd></div>
        <div class="flex justify-between"><dt class="text-slate-500">Entry Year</dt><dd class="font-medium"><?php echo e($student->entry_year ?? '—'); ?></dd></div>
      </dl>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale049caea0b4efc5bb49a3781ed38b732)): ?>
<?php $attributes = $__attributesOriginale049caea0b4efc5bb49a3781ed38b732; ?>
<?php unset($__attributesOriginale049caea0b4efc5bb49a3781ed38b732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale049caea0b4efc5bb49a3781ed38b732)): ?>
<?php $component = $__componentOriginale049caea0b4efc5bb49a3781ed38b732; ?>
<?php unset($__componentOriginale049caea0b4efc5bb49a3781ed38b732); ?>
<?php endif; ?>

<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/student/dashboard/index.blade.php ENDPATH**/ ?>