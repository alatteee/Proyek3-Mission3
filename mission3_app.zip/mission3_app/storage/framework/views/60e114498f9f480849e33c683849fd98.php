<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null, 'subtitle' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null, 'subtitle' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="bg-white rounded-2xl shadow-sm border border-slate-200">
  <?php if($title): ?>
    <div class="px-6 py-4 border-b border-slate-100">
      <h2 class="text-base font-semibold text-slate-800"><?php echo e($title); ?></h2>
      <?php if($subtitle): ?>
        <p class="text-sm text-slate-500 mt-0.5"><?php echo e($subtitle); ?></p>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <div class="p-6">
    <?php echo e($slot); ?>

  </div>
</section>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/components/admin/form-card.blade.php ENDPATH**/ ?>