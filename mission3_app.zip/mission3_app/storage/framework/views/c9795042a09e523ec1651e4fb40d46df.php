<?php if (isset($component)) { $__componentOriginale049caea0b4efc5bb49a3781ed38b732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale049caea0b4efc5bb49a3781ed38b732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student.layout','data' => ['title' => 'My Courses']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('student.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My Courses']); ?>
  <?php if(session('ok')): ?>
    <div class="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-700">
      <?php echo e(session('ok')); ?>

    </div>
  <?php endif; ?>

  <div class="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
    <table class="min-w-full text-sm">
      <thead class="bg-slate-50 text-slate-700">
        <tr>
          <th class="px-4 py-3 text-left font-semibold">Code</th>
          <th class="px-4 py-3 text-left font-semibold">Name</th>
          <th class="px-4 py-3 text-left font-semibold">Enrolled At</th>
          <th class="px-4 py-3 text-left font-semibold">Grade</th>
          <th class="px-4 py-3 text-right font-semibold">Action</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-200 text-slate-900">
        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-slate-50">
            <td class="px-4 py-3 font-mono"><?php echo e($c->course_code); ?></td>
            <td class="px-4 py-3"><?php echo e($c->course_name); ?></td>
            <td class="px-4 py-3"><?php echo e(\Illuminate\Support\Carbon::parse($c->pivot->enroll_date)->format('d M Y')); ?></td>
            <td class="px-4 py-3">
              <?php if($c->pivot->letter): ?>
                <span class="inline-flex items-center gap-2">
                  <span class="rounded-full bg-blue-100 px-2 py-0.5 text-blue-700 text-xs font-semibold">
                    <?php echo e($c->pivot->letter); ?>

                  </span>
                  <span class="text-slate-600 text-sm">
                    <?php echo e($c->pivot->score ?? '—'); ?> / <?php echo e(number_format($c->pivot->grade_point,2)); ?>

                  </span>
                </span>
              <?php else: ?>
                <span class="text-slate-400">—</span>
              <?php endif; ?>
            </td>
            <td class="px-4 py-3">
              <div class="flex justify-end">
                <form method="post" action="<?php echo e(route('student.courses.drop',$c)); ?>"
                      onsubmit="return confirm('Drop course ini?')">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="rounded-lg bg-rose-600 px-3 py-1.5 text-white hover:bg-rose-700">
                    Drop
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="4" class="px-4 py-10 text-center text-slate-500">
              Belum ada course yang diambil.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
    <div class="p-4"><?php echo e($courses->links()); ?></div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale049caea0b4efc5bb49a3781ed38b732)): ?>
<?php $attributes = $__attributesOriginale049caea0b4efc5bb49a3781ed38b732; ?>
<?php unset($__attributesOriginale049caea0b4efc5bb49a3781ed38b732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale049caea0b4efc5bb49a3781ed38b732)): ?>
<?php $component = $__componentOriginale049caea0b4efc5bb49a3781ed38b732; ?>
<?php unset($__componentOriginale049caea0b4efc5bb49a3781ed38b732); ?>
<?php endif; ?>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/student/courses/mine.blade.php ENDPATH**/ ?>