<?php if (isset($component)) { $__componentOriginal7651faf8e4a1e278424aad70c82de3ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7651faf8e4a1e278424aad70c82de3ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.layout','data' => ['title' => 'Students']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Students')]); ?>  
   <?php $__env->slot('header', null, []); ?> <h2 class="font-semibold text-xl text-gray-900">Students</h2> <?php $__env->endSlot(); ?>

  <div class="flex">

    <main class="flex-1 p-6">
      <?php if(session('ok')): ?>
        <div class="mb-4 rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-green-700">
          <?php echo e(session('ok')); ?>

        </div>
      <?php endif; ?>

      <div class="rounded-2xl border border-gray-200 bg-white shadow-md">
        <div class="flex items-center justify-between p-4">
          <a href="<?php echo e(route('admin.students.create')); ?>"
             class="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-500">+ New Student</a>

          <form method="get">
            <input name="q" value="<?php echo e($q); ?>"
                   placeholder="Search username/name/NIM…" class="rounded-lg border border-gray-300 px-3 py-2 text-sm">
          </form>
        </div>

        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-gray-700">
              <tr>
                <th class="px-4 py-3 text-left">NIM</th>
                <th class="px-4 py-3 text-left">Username</th>
                <th class="px-4 py-3 text-left">Full Name</th>
                <th class="px-4 py-3 text-left">Entry Year</th>
                <th class="px-4 py-3 text-left">Major</th>
                <th class="px-4 py-3 text-left">Phone</th>
                <th class="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 text-gray-800">
              <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-4 py-3 font-mono"><?php echo e($s->nim); ?></td>
                  <td class="px-4 py-3"><?php echo e($s->user->username); ?></td>
                  <td class="px-4 py-3"><?php echo e($s->user->full_name); ?></td>
                  <td class="px-4 py-3"><?php echo e($s->entry_year); ?></td>
                  <td class="px-4 py-3"><?php echo e($s->major); ?></td>
                  <td class="px-4 py-3"><?php echo e($s->phone); ?></td>
                  <td class="px-4 py-3">
                    <div class="flex justify-end gap-2">
                        <a href="<?php echo e(route('admin.students.show', $s)); ?>"
                            class="rounded-lg border border-gray-300 px-3 py-1.5 text-gray-700 hover:bg-gray-100">Detail</a>

                      <a href="<?php echo e(route('admin.students.edit', $s)); ?>"
                         class="rounded-lg border border-gray-300 px-3 py-1.5 text-gray-700 hover:bg-gray-100">Edit</a>
                      <form method="post" action="<?php echo e(route('admin.students.destroy', $s)); ?>"
                            onsubmit="return confirm('Hapus student ini?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="rounded-lg bg-red-600 px-3 py-1.5 text-white hover:bg-red-500">Delete</button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-4 py-8 text-center text-gray-500">No data</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <div class="p-4"><?php echo e($students->links()); ?></div>
      </div>
    </main>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7651faf8e4a1e278424aad70c82de3ba)): ?>
<?php $attributes = $__attributesOriginal7651faf8e4a1e278424aad70c82de3ba; ?>
<?php unset($__attributesOriginal7651faf8e4a1e278424aad70c82de3ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7651faf8e4a1e278424aad70c82de3ba)): ?>
<?php $component = $__componentOriginal7651faf8e4a1e278424aad70c82de3ba; ?>
<?php unset($__componentOriginal7651faf8e4a1e278424aad70c82de3ba); ?>
<?php endif; ?>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/admin/students/index.blade.php ENDPATH**/ ?>