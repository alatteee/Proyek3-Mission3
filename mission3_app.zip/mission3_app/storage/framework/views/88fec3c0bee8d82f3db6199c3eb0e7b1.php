<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name' => 'circle', 'class' => 'size-5']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name' => 'circle', 'class' => 'size-5']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
  $paths = [
    'home' => 'M3 10.5L12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1v-10.5z',
    'layers' => 'M12 3l9 5-9 5-9-5 9-5zm-9 9l9 5 9-5M3 21l9 5 9-5',
    'users' => 'M16 14a4 4 0 1 0-8 0M3 21a7 7 0 0 1 14 0M19 8a3 3 0 1 1-6 0',
    'chart' => 'M4 20h16M7 16V9m5 7V5m5 11v-8',
    'crown' => 'M3 18l2-9 5 4 4-4 3 9H3z',
    'circle' => 'M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18z'
  ];
?>
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"
     class="<?php echo e($class); ?>"><path d="<?php echo e($paths[$name] ?? $paths['circle']); ?>" stroke-linecap="round" stroke-linejoin="round"/></svg>
<?php /**PATH D:\Proyek 3\Mission3\Proyek3-Mission3\mission3_app\resources\views/components/admin/icon.blade.php ENDPATH**/ ?>